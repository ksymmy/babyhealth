import { HTTP } from '/util/http.js';
let http = new HTTP();
var hylbIndex, hylbArray = [], duesInfo, dataId;
Page({
  data: {
    hylbIndex: 0,
    hylbArray: [],
    duesInfo: {},
    typeShow: 1,
    checkItems: [
      { name: '通过', value: '1', checked: true },
      { name: '不通过', value: '3' }
    ]
  }
  , onLoad(e) {
    dd.showLoading({
      content: '加载中',
    });
    dataId = e.id;
    if (dataId != null) {
      //获取表单信息
      http.request({
        url: 'duesStandard/selectInfo?id=' + dataId,
        success: (res) => {
          duesInfo = res;
          this.setData({
            duesInfo: duesInfo
          });
          console.log(duesInfo);
        }
      });
    }
  }
  , onReady() {
    http.request({
      url: 'dict/getDictListByCode?code=member_type',
      success: (res) => {
        hylbArray = [];
        for (var i = 0; i < res.length; i++) {
          var row = res[i];
          if (duesInfo != null && duesInfo.type != null) {
            if (row.id == duesInfo.type) {
              hylbIndex = i;
            }
          }
          var aa = { id: row.id, name: row.name };
          hylbArray.push(aa);
        }

        this.setData({
          hylbIndex: hylbIndex,
          hylbArray: hylbArray,
        });
      }
    });
    dd.hideLoading();
  },
  radioChange(e) {
    this.setData({
      typeShow: e.detail.value
    });
    console.log('你选择的框架是：', e.detail.value);
  }
  , onSubmit(e) {
    var dataJson = e.detail.value;
    if (dataJson.money == "") {
      dd.alert({ content: "会费不能为空！" });
      return false;
    } else {
      var moneyTest = /^\d+(\.\d+)?$/.test(dataJson.money);
      if (!moneyTest || parseInt(dataJson.money) < 0) {
        dd.alert({ content: "请输入正确的会费！" });
        return false;
      }
    }
    dd.showLoading({
      content: '加载中',
    });
    http.request({
      url: 'duesStandard/saveOrUpdate',
      method: 'POST',
      data: JSON.stringify(dataJson),
      success: (res) => {
        dd.alert({
          content: "操作成功",
          success: (result) => {
            dd.hideLoading();
            dd.redirectTo({ url: "list" });
          }
        });
      }
    });
  }, changeHylb(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
    this.setData({
      hylbIndex: e.detail.value,
    });
  }
})